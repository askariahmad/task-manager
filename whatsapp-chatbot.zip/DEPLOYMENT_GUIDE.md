# Deployment Guide (Heroku Example)

This guide provides basic steps to deploy the WhatsApp Chatbot to Heroku.

## Prerequisites
1.  A Heroku account (free tier available).
2.  [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli) installed and authenticated (`heroku login`).
3.  [Git](https://git-scm.com/downloads) installed.
4.  Twilio Account SID, Auth Token, and Twilio WhatsApp phone number.

## Build Instructions
1.  Navigate to the project's root directory (where `pom.xml` is located).
2.  Build the executable JAR file using Maven:
    ```bash
    mvn clean package
    ```
    This will create the JAR file in the `target/` directory (e.g., `target/whatsapp-chatbot-0.0.1-SNAPSHOT.jar`).

## Heroku Deployment Steps

1.  **Initialize Git Repository (if not already):**
    ```bash
    git init
    git add .
    git commit -m "Initial commit for Heroku deployment"
    ```

2.  **Create a Heroku App:**
    ```bash
    heroku create your-unique-app-name 
    ```
    (If you omit `your-unique-app-name`, Heroku will generate one for you). This also adds a `heroku` git remote.

3.  **Set Environment Variables on Heroku:**
    Replace `your_account_sid`, `your_auth_token`, and `your_twilio_whatsapp_number` with your actual Twilio credentials.
    ```bash
    heroku config:set TWILIO_ACCOUNT_SID=your_account_sid
    heroku config:set TWILIO_AUTH_TOKEN=your_auth_token
    heroku config:set TWILIO_PHONE_NUMBER=whatsapp:+your_twilio_whatsapp_number 
    # Example: heroku config:set TWILIO_PHONE_NUMBER=whatsapp:+14155238886 
    ```
    Also, set the Java runtime if needed (Heroku usually auto-detects Java):
    ```bash
    heroku config:set JAVA_OPTS="-Xmx512m" 
    # Optional: Adjust memory settings as needed for the free tier.
    ```

4.  **Deploy to Heroku:**
    Push your code to the Heroku remote:
    ```bash
    git push heroku master 
    # Or main, if your default branch is main: git push heroku main
    ```

5.  **Check Application Logs:**
    ```bash
    heroku logs --tail
    ```
    Look for messages indicating Spring Boot has started and your application is running.

6.  **Configure Twilio Webhook:**
    *   Once deployed, Heroku will give you a URL for your app (e.g., `https://your-unique-app-name.herokuapp.com`).
    *   In your Twilio console, navigate to your WhatsApp sender's configuration.
    *   Set the webhook URL for "WHEN A MESSAGE COMES IN" to `https://your-unique-app-name.herokuapp.com/api/whatsapp/webhook` (using POST method).

## Other Free Cloud Platform Options:

*   **Google Cloud App Engine (Standard):**
    *   Good free tier.
    *   Requires `app.yaml` for configuration.
    *   Deployment via `gcloud app deploy`.
    *   Good for integrating with Firestore/Datastore for persistence.
*   **AWS Elastic Beanstalk:**
    *   Free tier often available for new accounts (12 months).
    *   More complex, but powerful.
*   **Fly.io / Oracle Cloud Free Tier:**
    *   Also offer free resources that might be suitable. May require Docker knowledge (Fly.io) or specific ARM builds (Oracle).

Remember to check the current terms and limitations of any free tier, as they can change.
